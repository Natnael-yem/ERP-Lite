import { Button, Checkbox, ConfigProvider, Flex, Input } from "antd";
import { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { useFrappeAuth } from 'frappe-react-sdk'
import Amharic from '../data/Amharic.json';
import English from '../data/English.json';
const Login = () => {
    const LangSelect = localStorage.getItem('Language');
    const Language = LangSelect === 'አማርኛ' ? Amharic.amharic : English.english;
    const {
        currentUser,
        isValidating,
        isLoading,
        login,
        logout,
        error,
        updateCurrentUser,
        getUserCookie,
    } = useFrappeAuth();
    
    const {
        handleSubmit,
        control,
        formState: { errors },
    } = useForm();
    console.log(currentUser)
    console.log(isValidating)

    useEffect(() => {
        if(currentUser){
            navigate('/dashboard');
            console.log(currentUser)
        }

    }, [currentUser]);


    const onSubmit = async (data) => {
        console.log("Form submitted successfully!", data);

        login({ username : data?.email, password : data?.password});
       
        // navigate('/dashboard');

    };
    const navigate = useNavigate();
    const [showPassword, setShowPassword] = useState(false);
    const handleRegister = () => {
        navigate('/register');
    }


    return (
        <Flex className="justify-center itens-center h-screen w-full">
            <div className="bg-gray-300/60 absolute z-20 h-screen w-full" />
            <img src="/assets/tourism/home/shape-2.png" alt="login" className=" top-[-2rem] animate-login absolute right-0 object-cover" />
            <Flex className="z-30 rounded-xl my-auto justify-around pb-10 sm:h-[90%]  sm:w-[28rem] w-[20rem] flex-col items-center bg-white">
                <img src="/assets/tourism/home/logo.png" alt="logo" className='sm:h-[10rem] h-[7rem] pb-3' />
                <p className="dm-sans-bold sm:text-[1.2rem]">{Language?.loginTitle}</p>
                <p className="dm-sans-light sm:text-[2rem] text-[1.4rem]">Sign In</p>
                <form
                    className="flex-col w-[80%] mx-auto sm:space-y-8 space-y-4  "
                    onSubmit={handleSubmit(onSubmit)}
                >
                    <Flex className="w-[100%] flex-col ">
                        <p className="dm-sans-light">{Language?.email}</p>
                        <Controller
                            name="email"
                            control={control}
                            rules={{
                                    required: "Email is required",
                                    pattern: {
                                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                        message: "Enter a valid email address",
                                    },
                                    maxLength: {
                                        value: 40,
                                        message: "Email must be at most 40 characters",
                                    },
                            }}
                            render={({ field }) => (
                                <Input
                                    size="small"
                                    {...field}
                                    label="email"
                                    className="w-[100%] py-2" />
                            )} />
                        {errors?.email && (
                            <p className="text-red-500 dm-sans-light pl-10 text-sm">{errors?.email?.message}</p>
                        )}
                    </Flex>
                    <Flex className="w-[100%]  flex-col space-y-1">
                        <p className="dm-sans-light">{Language?.password}</p>
                        <Controller
                            name="password"
                            control={control}
                            rules={{
                                required: "Password is required",
                                // minLength: {
                                //     value: 6,
                                //     message: "Password must be at least 6 characters",
                                // },
                            }}
                            render={({ field }) => (
                                <Input
                                    size="small"
                                    type={showPassword ? "text" : "password"}
                                    {...field}
                                    className="w-[100%] py-2"
                                    label="password"
                                    suffix={
                                        <Flex
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="cursor-pointer text-[1.2rem]"
                                        >
                                            {showPassword ? <FaEye /> : <FaEyeSlash />}
                                        </Flex>
                                    }
                                />
                            )} />
                        {errors?.password && (
                            <p className="text-red-500 dm-sans-light pl-10 text-sm">{errors?.password?.message}</p>
                        )}
                        <Flex className="justify-end items-center dm-sans-light w-[100%] pt-2">
                            {/* <Flex className="sm:space-x-4 space-x-1">
                                <Checkbox />
                                <p className="text-end  sm:text-[0.9rem] text-[0.8rem]">Remember Me</p>
                            </Flex> */}
                            <p className="text-end  sm:text-[0.9rem] text-[0.8rem]">{Language?.forgetPassword}</p>
                        </Flex>
                    </Flex>

                    <Flex className="">
                        <ConfigProvider theme={{
                            components: {
                                Button: {
                                    colorPrimary: '#0873BA',
                                    colorPrimaryHover: '#0873BA',
                                    colorPrimaryActive: '#0873BA'
                                }
                            }
                        }}>
                            <Button type="primary" size="large" htmlType="submit" className=" dm-sans-bold w-[100%]">{Language?.login}</Button>
                        </ConfigProvider>
                    </Flex>
                </form>
                <Flex className="w-[80%] pt-3">
                    <button onClick={handleRegister} className="w-[100%] border-2 rounded-lg py-2 border-[#0873BA] dm-sans-bold text-[#0873BA]">{Language?.register}</button>
                </Flex>
            </Flex>
        </Flex>
    );
};

export default Login;