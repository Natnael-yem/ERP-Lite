import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
// import AnnouncementBar from "./Announcement Bar";

const Header = ({setLang, lang}) => {
    return (
        <div>
            {/* <AnnouncementBar /> */}
            <Navbar setLang={setLang} lang={lang}/>
            <Outlet />
        </div>
    );
};

export default Header;