
import { Empty, Flex, Modal } from "antd";
import { MdOutlineDoubleArrow } from "react-icons/md";
import { HiOutlineHomeModern } from "react-icons/hi2";
import { animate, motion, useMotionValue, useTransform } from "motion/react"
import { useEffect, useState } from "react"
import { PiPlusBold } from "react-icons/pi";
import Amharic from '../../data/Amharic.json';
import English from '../../data/English.json';
import { GiArchiveRegister } from "react-icons/gi";
import { FaEdit } from "react-icons/fa";
import { IoCheckmarkDoneOutline } from "react-icons/io5";
import { FormControl, FormHelperText, InputLabel, MenuItem, Select } from "@mui/material";
import { useForm, useWatch } from "react-hook-form";
import { Pagination, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from "swiper/react";
import 'swiper/css';
import 'swiper/css/effect-coverflow';
import { useFrappeGetDocList } from "frappe-react-sdk";
import { Element } from "react-scroll";

const Service = () => {
    const {
        handleSubmit,
        control,
        register,
        formState: { errors, isValid },
        trigger,
        getValues,
        watch,
    } = useForm({
        mode: "onBlur",
        reValidateMode: "onChange",
    });
    const mainCategory = useWatch({ control, name: 'main_category' });
    const subCategory = useWatch({ control, name: 'sub_category' });
    const filterSub = useWatch({ control, name: 'sub_sub_category' });

    const { data: main = [] } = useFrappeGetDocList('main_categories', {
        fields: ['service_name', 'service_name_amharic'],
    });
    console.log(main)
    const { data: sub = [] } = useFrappeGetDocList('sub_categories', {
        fields: ['sub_category_name', 'main_service_name', 'sub_category_name_amharic', 'description', 'description_amharic'],
    });
    console.log(sub)
    const { data: subSub = [] } = useFrappeGetDocList('sub_sub_categories', {
        fields: ['sub_sub_category_name', 'sub_sub_category_name_amharic', 'sub_category_name', 'sub_description', 'sub_description_amharic'],
        limit: 500,
    });
    console.log(subSub)
    const Mainoptionss = main?.map((item) => ({
        label: item?.service_name_amharic,
        value: item?.service_name,
    }));
    console.log(Mainoptionss)

    const suboptionss = sub?.filter((item) => item?.main_service_name === mainCategory)
        .map((item) => ({
            label: item?.sub_category_name_amharic,
            value: item?.sub_category_name,
        }));
    console.log(suboptionss)
    const SubSuboptionss = subSub?.filter((item) => item?.sub_category_name === subCategory)
        .map((item) => ({
            label: item?.sub_sub_category_name_amharic,
            value: item?.sub_sub_category_name,
        }));
    const filterSubCategory = subSub?.filter((item) => item?.sub_sub_category_name === filterSub);
    console.log(filterSubCategory);
    const filterCategory = sub?.filter((item) => item?.sub_category_name === subCategory);
    console.log(filterSubCategory?.[0]?.sub_description_amharic, 'jgh');
    console.log(filterSubCategory?.sub_description_amharic, 'jgh');
    console.log(filterCategory?.[0]?.description_amharic, 'hhjh')
    const LangSelect = localStorage.getItem('Language');
    const Language = LangSelect === 'አማርኛ' ? Amharic.amharic : English.english;
    const [show, setShow] = useState(false);
    const count = useMotionValue(0)
    const rounded = useTransform(() => Math.round(count.get()));
    useEffect(() => {
        const controls = animate(count, 99, { duration: 10 })
        return () => controls.stop()
    }, []);
    useEffect(() => {
        if (show) {
            document.body.style.overflow = "hidden";
        } else {
            document.body.style.overflow = "auto";
        }
        return () => {
            document.body.style.overflow = "auto";
        };
    }, [show]);
    const handleService = () => {
        setShow(true);
    }
    const handleOk = () => {
        setShow(false);
    }
    return (
        <Element name="section3">
            <Flex className="flex-col py-16 min-h-[100%] items-center space-y-10 mb-10 bg-[#F2F5F9] z-20 mt-10">
                <Flex className="sm:px-28 px-10  md:flex-row flex-col w-[100%] mx-auto justify-between md:items-center">
                    <Flex className="flex-col lg:w-[50%] md:w-[70%] ">
                        <Flex className="items-center space-x-2">
                            < MdOutlineDoubleArrow className="text-[#F7961B] text-[1.2rem]" />
                            <p className="font-semibold dm-sans-bold text-[1.6rem]">{Language?.serviceTitle}</p>
                            < MdOutlineDoubleArrow className="text-[#F7961B] text-[1.2rem] rotate-180" />
                        </Flex>
                        <p className="dm-sans-bold text-[#16243D] lg:text-[3rem] sm:text-[2.4rem] text-[1.7rem] font-bold sm:w-[80%] w-[100%] ">{Language?.serviceSubTitle}</p>
                    </Flex>
                    <Flex className="lg:w-[37%] md:w-[70%] w-[100%] pt-5">
                        <p className="text-gray-600 text-[1.1rem]">{Language?.serviceDescription}</p>
                    </Flex>
                </Flex>
                <motion.div className="flex grid xl:grid-cols-3  md:grid-cols-2 grid-cols-1 gap-6 z-40 pb-10"
                    initial={{ y: 150 }}
                    whileInView={{ y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    layout
                    transition={{ duration: 2, ease: "easeOut" }}>
                    <Flex className="bg-white flex-col hover:bg-[#0974BC] hover:text-white transition-all duration-1000 ease-in-out rounded-md sm:h-[17rem] h-[18rem] sm:w-[22rem] w-[80%] mx-auto  mb-2  border shadow-md">
                        <Flex className=" h-[8rem] items-center justify-between overflow-hidden relative rounded-md">
                            <Flex
                                className=" w-[13rem] h-[12rem] text-[3rem] justify-end items-end pr-16 pb-6 mt-[-5.5rem] ml-[-3rem] rounded-full"
                            >
                                < GiArchiveRegister className="" />
                            </Flex>
                        </Flex>
                        <Flex className="flex-col px-9 space-y-3 mb-7">
                            <p className="dm-sans-bold text-[1.5rem] ">{Language?.newRegistration?.title}</p>
                            <p className="dm-sans-light ">{Language?.newRegistration?.description}</p>
                        </Flex>
                        <p onClick={handleService} className="dm-sans-bold mb-2 z-30 border w-auto mx-auto px-4 py-2 rounded-lg border-2 border-[#F7961B] hover:bg-[#F7961B] cursor-pointer">{Language?.serviceButton}</p>
                        <img src="/assets/tourism/home/shape.png" alt="service" className="opacity-25 w-[12rem] flex absolute mt-[7rem] sm:ml-[10rem] ml-[5rem]" />
                    </Flex>
                    <Flex className="bg-white  hover:bg-[#0974BC] hover:text-white transition-all duration-1000 ease-in-out rounded-md sm:h-[17rem] h-[18rem] sm:w-[22rem] w-[80%] mx-auto mb-2 flex-col shadow-md border">
                        <Flex className=" h-[8rem] items-center justify-between overflow-hidden relative rounded-md">
                            <Flex
                                className=" w-[13rem] h-[12rem] text-[3rem] justify-end items-end pr-16 pb-6 mt-[-5.5rem] ml-[-3rem] rounded-full"
                            >
                                <FaEdit className="" />
                            </Flex>

                        </Flex>
                        <Flex className="flex-col px-9 space-y-3 mb-7">
                            <p className="dm-sans-bold text-[1.5rem] ">{Language?.registrationAmendment?.title}</p>
                            <p className="dm-sans-light">{Language?.registrationAmendment?.description}</p>
                        </Flex>
                        <button className="dm-sans-bold mb-2 z-30 border w-auto mx-auto px-4 py-2 rounded-lg border-2 border-[#F7961B] hover:bg-[#F7961B] cursor-pointer">{Language?.serviceButton}</button>
                        <img src="/assets/tourism/home/shape.png" alt="service" className="opacity-25 w-[12rem] flex absolute mt-[7rem] sm:ml-[10rem] ml-[5rem]" />
                    </Flex>
                    <Flex className="bg-white  hover:bg-[#0974BC] hover:text-white transition-all duration-1000 ease-in-out rounded-md sm:h-[17rem] h-[18rem] sm:w-[22rem] w-[80%] mx-auto mb-2 flex-col shadow-md border">
                        <Flex className=" h-[8rem] items-center justify-between overflow-hidden relative rounded-md">
                            <Flex
                                className=" w-[13rem] h-[12rem] text-[3rem] justify-end items-end pr-16 pb-6 mt-[-5.5rem] ml-[-3rem] rounded-full"
                            >
                                <FaEdit className="" />
                            </Flex>

                        </Flex>
                        <Flex className="flex-col px-9 space-y-3 mb-7">
                            <p className="dm-sans-bold text-[1.5rem] ">{Language?.registrationAmendment?.title}</p>
                            <p className="dm-sans-light">{Language?.registrationAmendment?.description}</p>
                        </Flex>
                        <button className="dm-sans-bold mb-2 z-30 border w-auto mx-auto px-4 py-2 rounded-lg border-2 border-[#F7961B] hover:bg-[#F7961B] cursor-pointer">{Language?.serviceButton}</button>
                        <img src="/assets/tourism/home/shape.png" alt="service" className="opacity-25 w-[12rem] flex absolute mt-[7rem] sm:ml-[10rem] ml-[5rem]" />
                    </Flex>
                    {/* <Flex className="bg-white  hover:bg-[#0974BC] hover:text-white transition-all duration-1000 ease-in-out rounded-md sm:h-[17rem] h-[18rem] sm:w-[22rem] w-[80%] mx-auto mb-2 flex-col shadow-md border">
                    <Flex className=" h-[8rem] items-center justify-between overflow-hidden relative rounded-md">
                        <Flex
                            className=" w-[13rem] h-[12rem] text-[3rem] justify-end items-end pr-16 pb-6 mt-[-5.5rem] ml-[-3rem] rounded-full"
                        >
                            <HiOutlineHomeModern className="" />
                        </Flex>

                    </Flex>
                    <Flex className="flex-col px-9 space-y-3 mb-7">
                        <p className="dm-sans-bold text-[1.5rem] ">Licensing</p>
                        <p className="dm-sans-light">Lorem ipsum dolor amet consectetur
                            adipiscing elit do eiusmod tempor incid
                            idunt ut labore.</p>
                    </Flex>
                    <p className="dm-sans-bold mb-2 z-30 border w-auto mx-auto px-4 py-2 rounded-lg border-2 border-[#F7961B] hover:bg-[#F7961B] cursor-pointer">{Language?.serviceButton}</p>
                    <img src="/assets/tourism/home/shape.png" alt="service" className="opacity-25 w-[12rem] flex absolute mt-[7rem] sm:ml-[10rem] ml-[5rem]" />
                </Flex> */}
                </motion.div>
                <Modal
                    open={show}
                    onOk={handleOk}
                    onCancel={() => setShow(false)}
                    footer={false}
                    width={1000}
                    className="mt-[-4rem]">
                    <Flex className="flex-col min-h-[35rem] ">
                        <p className="dm-sans-bold text-[1.7rem] ">{Language?.newRegistration?.title}</p>
                        <hr />
                        <Flex className="sm:flex-row flex-col w-[100%] min-h-[35rem] pt-4">
                            <Flex className="sm:flex-col flex-col-reverse sm:pl-6 pt-3 space-y-3 mb-7 sm:w-[50%] rounded-lg bg-[#F9FAFB] ">
                                <Flex className="w-[100%] flex-col  space-y-2">
                                    <Flex className="flex-col space-y-5 space-x-6">
                                        <p className="font-semibold text-[1.1rem]">{Language?.General?.[0]?.sector}</p>
                                        <Flex className=" w-[70%]  flex-col  space-y-3">
                                            <Flex className="w-[100%]  flex-col space-y-2">
                                                <FormControl
                                                    size="small"
                                                    fullWidth
                                                    error={!!errors.main_category}
                                                >
                                                    <InputLabel id="institution-Main-label">
                                                        {Language?.General?.[0]?.main_category}
                                                    </InputLabel>
                                                    <Select
                                                        labelId="institution-main-label"
                                                        id="institution-main"
                                                        // defaultValue={data?.main_category || ''}
                                                        label={Language?.General?.[0]?.main_category || ""}
                                                        {...register("main_category", {
                                                            required: `${Language?.General?.[0]?.main_category_error}`,
                                                        })}
                                                        className="w-full text-gray-500 public-sans-body hover:shadow-lg hover:shadow-cyan-500/30"
                                                    >
                                                        {Mainoptionss?.map((option) => (
                                                            <MenuItem key={option.value} value={option.value}>
                                                                {option.label}
                                                            </MenuItem>
                                                        ))}
                                                    </Select>
                                                    {errors.main_category && (
                                                        <FormHelperText>{errors.main_category.message}</FormHelperText>
                                                    )}
                                                </FormControl>
                                            </Flex>
                                            <Flex className="w-[100%]  flex-col space-y-2">
                                                <FormControl
                                                    size="small"
                                                    fullWidth
                                                    error={!!errors.sub_category}
                                                >
                                                    <InputLabel id="institution-sub-label">
                                                        {Language?.General?.[0]?.sub_category}
                                                    </InputLabel>
                                                    <Select
                                                        labelId="institution-sub-label"
                                                        id="institution-main"
                                                        // defaultValue={data?.sub_category || ''}
                                                        label={Language?.General?.[0]?.sub_category || ""}
                                                        {...register("sub_category", {
                                                            required: `${Language?.General?.[0]?.sub_category_error}`,
                                                        })}
                                                        className="w-full text-gray-500 public-sans-body hover:shadow-lg hover:shadow-cyan-500/30"
                                                    >
                                                        {suboptionss?.map((option) => (
                                                            <MenuItem key={option.value} value={option.value}>
                                                                {option.label}
                                                            </MenuItem>
                                                        ))}
                                                    </Select>
                                                    {errors.sub_category && (
                                                        <FormHelperText>{errors.sub_category.message}</FormHelperText>
                                                    )}
                                                </FormControl>
                                            </Flex>
                                            {SubSuboptionss?.length >= 1 &&
                                                <Flex className="w-[100%]  flex-col space-y-2">
                                                    <FormControl
                                                        size="small"
                                                        fullWidth
                                                        error={!!errors.sub_sub_category}
                                                    >
                                                        <InputLabel id="institution-sub-label">
                                                            {Language?.General?.[0]?.sub_sub_category}
                                                        </InputLabel>
                                                        <Select
                                                            labelId="institution-sub-label"
                                                            id="institution-main"
                                                            // defaultValue={data?.sub_sub_category || ''}
                                                            label={Language?.General?.[0]?.sub_sub_category || ""}
                                                            {...register("sub_sub_category", {
                                                                required: `${Language?.General?.[0]?.sub_sub_category_error}`,
                                                            })}
                                                            className="w-full text-gray-500 public-sans-body hover:shadow-lg hover:shadow-cyan-500/30"
                                                        >
                                                            {SubSuboptionss?.map((option) => (
                                                                <MenuItem key={option.value} value={option.value}>
                                                                    {option.label}
                                                                </MenuItem>
                                                            ))}
                                                        </Select>
                                                        {errors.sub_sub_category && (
                                                            <FormHelperText>{errors.sub_sub_category.message}</FormHelperText>
                                                        )}
                                                    </FormControl>
                                                </Flex>
                                            }
                                        </Flex>
                                    </Flex>
                                </Flex>
                                <Flex className="flex-col">
                                    <p className="text-[1.2rem] font-semibold">በማንኛውም ዘርፍ መማላት ያለብት መረጃዎች</p>
                                    <Flex className="flex-col w-[70%] mx-auto space-y-1">
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>ኢንቨስትመንት ፍቃድ</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>ብሉ ብሪንት</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>የአዋጭነት ጥናት</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>ካርታ(በኪራይ ከሆነ በትንሹ የአምስት ውል)</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>የግንባታ ፍቃድ</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>ማመልከቻ (ለአዲስ አበባ ባህል ኪነ-ጥብብና ቱሪዝም ቢሮ ማህተም እና ቁጥር ያለው)</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>የባለቤት መታወቂያ</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>ቲን</p>
                                        </Flex>
                                        <Flex className="space-x-2 items-center">
                                            <IoCheckmarkDoneOutline />
                                            <p>የማህበር ከሆነ መመሰረቻ እና መተዳደሪያ ደንብ</p>
                                        </Flex>
                                    </Flex>
                                </Flex>
                            </Flex>
                            <Flex className="flex-col sm:w-[50%] justify-center ">
                                <Flex className="overflow-y-auto w-[95%] justify-center mx-auto h-[29rem]">
                                    {suboptionss?.length >= 1 ?
                                        <Flex>
                                            {SubSuboptionss?.length >= 1 ?
                                                <Flex className="flex-col">
                                                    <p className="font-bold text-[1.2rem]">{filterSubCategory?.[0]?.sub_sub_category_name_amharic}</p>
                                                    <p className="font-semibold">ማሟላት የሚገባው መስፈርት</p>
                                                    <p>
                                                        {filterSubCategory?.[0]?.sub_description_amharic
                                                            .split('\n')
                                                            .map((line, index) => (
                                                                <p key={index}>{line}</p>
                                                            ))}
                                                    </p>
                                                </Flex>
                                                :
                                                <Flex className="flex-col">
                                                    <p className="font-semibold">{filterSubCategory?.[0]?.sub_category_name_amharic}</p>
                                                    <p>ማሟላት የሚገባው መስፈርት</p>
                                                    <p>{filterCategory?.[0]?.description_amharic
                                                        .split('\n')
                                                        .map((line, index) => (
                                                            <p key={index}>{line}</p>
                                                        ))}</p>
                                                </Flex>
                                            }
                                        </Flex>
                                        :
                                        <Flex>
                                            <Empty description={Language?.choose_service} />
                                        </Flex>
                                    }
                                </Flex>
                                <button className="bg-[#F7961B] w-[10rem] h-[4rem] mx-auto text-white px-4 py-2 font-semibold rounded-lg mt-4">{Language?.toserviceButton}</button>
                            </Flex>
                        </Flex>
                    </Flex>
                </Modal>
                {/* <Flex className="w-[90%] mx-auto  pb-20">
                    <Swiper
                        slidesPerView={'auto'}
                        spaceBetween={30}
                        autoplay={{
                            delay: 2000,
                            disableOnInteraction: false,
                        }}
                        modules={[Autoplay]}
                        className="mySwiper h-[11rem] w-[100%]"
                    >
                        <SwiperSlide className=" rounded-tl-[2rem] rounded-br-[2rem] bg-[#FFFFFF] p-4">
                            <Flex className="flex-col md:items-center">
                                <Flex className="items-center">
                                    <img src="/assets/tourism/home/shapes5.png" className="absolute top-0 right-0  w-[20rem] mix-blend-luminosity opacity-40" alt='dk' />
                                    <img src="/assets/tourism/home/service.png" className="hover:scale-[90%] h-[7rem]" alt="people" />
                                    <Flex className="items-end space-x-1">
                                        <motion.pre className="text-[2.4rem] pb-1 font-serif font-semibold">{rounded}</motion.pre>
                                        <p className="text-[2rem] pb-2  font-bold">k</p>
                                    </Flex>
                                </Flex>
                                <p className="text-gray-700 text-[1.5rem]">{Language?.giveServices}</p>
                            </Flex>
                        </SwiperSlide>
                        <SwiperSlide className="rounded-tl-[2rem] rounded-br-[2rem] rounded-lg bg-[#FFFFFF] p-4">
                            <Flex className="flex-col md:items-center">
                                <Flex className="items-center">
                                    <img src="/assets/tourism/home/shapes5.png" className="absolute top-0 right-0  w-[20rem] mix-blend-luminosity opacity-40" alt='dk' />
                                    <img src="/assets/tourism/home/people.png" className=" hover:scale-[90%] h-[7rem]" alt="people" />
                                    <Flex className="items-end">
                                        <motion.pre className="text-[2.4rem] pb-1  font-serif font-semibold">{rounded}</motion.pre>
                                        <PiPlusBold className="text-[2rem] mb-4  " />
                                    </Flex>
                                </Flex>
                                <p className="text-gray-700 text-[1.5rem]">{Language?.team}</p>
                            </Flex>
                        </SwiperSlide>
                        <SwiperSlide className="rounded-tl-[2rem] rounded-br-[2rem] rounded-lg bg-[#FFFFFF] p-4">
                            <Flex className="flex-col md:items-center">
                                <Flex className="items-center">
                                    <img src="/assets/tourism/home/shapes5.png" className="absolute top-0 right-0  w-[20rem] mix-blend-luminosity opacity-40" alt='dk' />
                                    <img src="/assets/tourism/home/user.png" className=" hover:scale-[90%] h-[7rem]" alt="people" />
                                    <Flex className="items-end space-x-1">
                                        <motion.pre className="text-[2.4rem] pb-1  font-serif font-bold">{rounded}</motion.pre>
                                        <p className="text-[2rem] pb-3  font-sans font-bold">k</p>
                                    </Flex>
                                </Flex>
                                <p className="text-gray-700 text-[1.5rem]">{Language?.customer}</p>
                            </Flex>
                        </SwiperSlide>
                        <SwiperSlide className="rounded-tl-[2rem] rounded-br-[2rem] rounded-lg bg-[#FFFFFF] p-4">
                            <Flex className="flex-col md:items-center">
                                <Flex className="items-center">
                                    <img src="./shapes5.png" className="absolute top-0 right-0  w-[20rem] mix-blend-luminosity opacity-40" alt='dk' />
                                    <img src="./success.png" className=" hover:scale-[90%] h-[7rem]" alt="people" />
                                    <Flex className="items-end">
                                        <motion.pre className="text-[2.4rem] pb-1  font-serif font-bold">{rounded}</motion.pre>
                                        <p className="text-[2rem] pb-3  font-sans font-semibold">%</p>
                                    </Flex>
                                </Flex>
                                <p className="text-gray-700 text-[1.5rem]">{Language?.rate}</p>
                            </Flex>
                        </SwiperSlide>

                    </Swiper>
                </Flex> */}
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <div className="w-[100%] rounded-2xl">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.5985557365607!2d38.7621756943472!3d9.009035881643486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b8500099b15a9%3A0xda9fe5eb92cfb33a!2z4Yuo4Yqg4Yuy4Yi1IOGKoOGJoOGJoyDhiaPhiIXhiI3hjaMg4Yqq4YqQIOGMpeGJoOGJpeGKkyDhibHhiKrhi53hiJ0g4Ymi4YiuLUFkZGlzIEFiYWJhIEN1bHR1cmUsIEFydHMgJlRvdXJpc20gQnVyZWF1!5e0!3m2!1sen!2set!4v1748508745527!5m2!1sen!2set"
                            width="1400"
                            height="200"
                            className="rounded-2xl"
                            style={{ border: 0 }}
                            allowFullScreen
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                        ></iframe>
                    </div>
                </div>
            </Flex>
        </Element>
    );
};

export default Service;