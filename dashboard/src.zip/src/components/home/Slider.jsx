import { Flex } from "antd";
import { AnimatePresence, motion } from "motion/react"
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation } from "swiper/modules";
import { IoIosArrowRoundBack } from "react-icons/io";
import { IoIosArrowBack } from "react-icons/io";
import { IoIosArrowForward } from "react-icons/io";
import Amharic from '../../data/Amharic.json';
import English from '../../data/English.json';
import "swiper/css";
import "swiper/css/navigation";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Element } from "react-scroll";

const Silder = () => {
    const navigate = useNavigate();
    const handleNav = () => {
        navigate('/login');
    }
    const handleRegister = () => {
        navigate('/register');
    }

    const LangSelect = localStorage.getItem('Language');
    const Language = LangSelect === 'አማርኛ' ? Amharic.amharic : English.english;
    const swiperRef = useRef(null);
    const [activeIndex, setActiveIndex] = useState(0);
    return (
        <Element name="section1">
            <Flex className='sm:h-[41.5rem] h-[30rem] overflow-hidden items-center justify-end'>
                <Flex className='w-[100%] flex-col items-start absolute z-40 space-y-6'>
                    <AnimatePresence mode="wait">
                        <motion.p
                            className={`${LangSelect === 'አማርኛ' ? 'xl:w-[35%] lg:w-[45%] sm:w-[50%] w-[60%] text-[1.4rem] ' : 'xl:w-[40%] lg:w-[50%] sm:w-[60%] w-[80%] text-[1.3rem] '} lg:text-[3rem] md:text-[2.5rem] sm:text-[2rem]   lg:ml-[20%] sm:ml-[30%] mx-auto dm-sans-bold  text-[#485468]`}
                            key={activeIndex}
                            initial={{ opacity: 0, y: -120 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: 20 }}
                            transition={{ duration: 1, ease: "easeOut" }}
                        >
                            {Language?.sliderTitle}
                        </motion.p>
                    </AnimatePresence>
                    <motion.div
                        initial={{ opacity: 0, y: 120 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`${LangSelect === 'አማርኛ' ? 'xl:w-[30%] lg:w-[35%] sm:w-[50%] w-[80%] ' : 'xl:w-[36%] lg:w-[35%] sm:w-[55%] w-[80%] '}  ' lg:ml-[20%] sm:ml-[30%]  mx-auto space-y-7`}
                        transition={{ duration: 1, ease: "easeOut" }}>
                        <motion.p className="text-gray-500 font-semibold "
                        >
                            {Language?.sliderSubTitle}
                        </motion.p>
                        <button className="ml-10 text-[#F7961B]" onClick={handleNav}>{Language?.login}</button>
                        <button onClick={handleRegister} className="ml-10 border sm:border-[#F7961B] border-[#F7961B] bg-[#F7961B] sm:text-black sm:bg-transparent text-white sm:hover:bg-[#F7961B] sm:hover:text-white px-5 py-2 rounded ">{Language?.register}</button>
                    </motion.div>
                </Flex>
                <Flex className="w-[70%]  ms-auto ">
                    <Swiper
                        spaceBetween={50}
                        slidesPerView={1}
                        onSlideChange={(swiper) => setActiveIndex(swiper.activeIndex)}
                        onSwiper={(swiper) => (swiperRef.current = swiper)}
                        autoplay={{
                            delay: 6500,

                            disableOnInteraction: false,
                        }}
                        speed={2500}
                        className=""
                        modules={[Autoplay, Navigation]} >

                        {["slider.jpg", "sky.jpg", "ggh.webp", "abrhot.jpg"].map((image, index) => (
                            <SwiperSlide className="overflow-hidden">
                                <motion.img
                                    key={activeIndex}
                                    initial={{ scale: 1 }}
                                    animate={{ scale: 1.3 }}
                                    transition={{ duration: 3, ease: "easeOut" }}
                                    src={`/assets/tourism/home/${image}`} alt="home"
                                    className={`${image === "slider.jpg" ? 'sm:h-[36rem] h-[28rem] mt-10' : 'h-[42rem]'} object-cover  w-fit ms-auto mask-gradient`} />
                            </SwiperSlide>
                        ))}
                    </Swiper>
                    <Flex className="absolute md:flex hidden z-40 top-[50%] space-y-5 lg:right-40 right-20 flex-col">
                        <button
                            onClick={() => swiperRef.current?.slidePrev()}
                            className=" transform -translate-y-1/2 border-2 border-[#F7961B] p-3 rounded-full shadow-lg  transition"
                        >
                            <IoIosArrowBack className="text-[#F7961B] text-[1.6rem]" />
                        </button>
                        <button
                            onClick={() => swiperRef.current?.slideNext()}
                            className=" transform -translate-y-1/2 border-2 border-[#F7961B] p-3 rounded-full shadow-lg transition"
                        >
                            <IoIosArrowForward className="text-[#F7961B] text-[1.6rem]" />
                        </button>
                    </Flex>
                    <div className="w-[100%] sm:h-[40rem] h-[30rem] left-0 top-[4.4rem] absolute z-30 bg-gradient-to-r sm:from-[#F2F5F9]/60 from-[#F2F5F9]/90 to-transparent" />
                </Flex>

                <Flex className='absolute z-20  sm:h-[40rem] h-[30rem] top-[4.4rem] left-0'>
                    <img src="/assets/tourism/home/animate.png" alt="home" className='animate object-cover' />
                </Flex>
            </Flex>
        </Element>
    );
};

export default Silder;